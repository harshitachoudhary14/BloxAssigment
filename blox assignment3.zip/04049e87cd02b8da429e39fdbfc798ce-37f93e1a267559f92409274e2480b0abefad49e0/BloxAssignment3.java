public class AddNumbers {
    public static String addNumbers(String val_a, String val_b) {
        try {
            int num_a = Integer.parseInt(val_a);
            int num_b = Integer.parseInt(val_b);
            
            int sum = num_a + num_b;
            
            return String.valueOf(sum);
        } catch (NumberFormatException e) {
            return "Invalid input. Please provide valid integer strings.";
        }
    }
    
    public static void main(String[] args) {
        // Test cases
        String result1 = addNumbers("10", "15");
        System.out.println(result1); // Expected output: "25"
        
        String result2 = addNumbers("-8", "5");
        System.out.println(result2); // Expected output: "-3"
        
        String result3 = addNumbers("-12", "-6");
        System.out.println(result3); // Expected output: "-18"
        
        String result4 = addNumbers("0", "17");
        System.out.println(result4); // Expected output: "17"
        
        String result5 = addNumbers("abc", "12");
        System.out.println(result5); // Expected output: "Invalid input. Please provide valid integer strings."
        
        String result6 = addNumbers("", "7");
        System.out.println(result6); // Expected output: "Invalid input. Please provide valid integer strings."
    }
}
